# CG Haubourdin — Site statique

Site statique du CG Haubourdin. Pour publier sur GitHub Pages :

1. Crée un dépôt sur GitHub et ne coche pas l'initialisation (README).
2. Depuis ce dossier local, initialise git et pousse :

```bash
git init
git add .
git commit -m "Initial commit - site"
git branch -M main
git remote add origin https://github.com/<ton-utilisateur>/<nom-du-repo>.git
git push -u origin main
```

3. Le workflow GitHub Actions `gh-pages` déploiera automatiquement le contenu du dépôt sur GitHub Pages (branche `gh-pages`).

4. Attends quelques minutes et visite `https://<ton-utilisateur>.github.io/<nom-du-repo>/`.

Remarque : le formulaire de contact ouvre le client mail de l'utilisateur (`mailto:`).
