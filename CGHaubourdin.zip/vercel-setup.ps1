# Script PowerShell pour déployer et lier automatiquement le projet sur Vercel
# Usage: Ouvrir PowerShell dans le dossier du projet et lancer `.ercel-setup.ps1`

param(
    [string]$Token = $env:VERCEL_TOKEN
)

if (-not $Token) {
    $Token = Read-Host -Prompt "Entrez votre VERCEL_TOKEN (depuis https://vercel.com/account/tokens)"
}

if (-not $Token) {
    Write-Error "VERCEL_TOKEN requis. Annulation."
    exit 1
}

Write-Host "Installation (ou vérification) de la CLI Vercel..." -ForegroundColor Cyan
npm install -g vercel | Out-Null

Write-Host "Déploiement initial et liaison du projet (peut prendre quelques secondes)..." -ForegroundColor Cyan
# Le déploiement ci-dessous crée le projet si nécessaire et le lie au dossier courant.
npx vercel --prod --token $Token --confirm

if ($LASTEXITCODE -ne 0) {
    Write-Error "Le déploiement Vercel a échoué. Vérifie ton token et réessaie."
    exit $LASTEXITCODE
}

Write-Host "Déploiement terminé et projet lié sur Vercel." -ForegroundColor Green
Write-Host "Pense à configurer les variables d'environnement dans Vercel (SMTP_*, RECIPIENT_EMAIL)." -ForegroundColor Yellow
