const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const RECIPIENT = process.env.RECIPIENT_EMAIL || 'kignamansorosi@gmail.com';

// Configureur SMTP via variables d'environnement
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.example.com',
  port: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT) : 587,
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || ''
  }
});

app.post('/send-email', async (req, res) => {
  const { name, email, message } = req.body || {};
  if (!name || !email || !message) return res.status(400).json({ error: 'Champs manquants' });

  const mailOptions = {
    from: `"${name}" <${email}>`,
    to: RECIPIENT,
    subject: `Contact site - ${name}`,
    text: `Nom: ${name}\nEmail: ${email}\n\n${message}`,
    html: `<p><strong>Nom:</strong> ${name}</p><p><strong>Email:</strong> ${email}</p><p>${message.replace(/\n/g,'<br>')}</p>`
  };

  try {
    await transporter.sendMail(mailOptions);
    res.json({ ok: true });
  } catch (err) {
    console.error('Erreur envoi mail:', err && err.message ? err.message : err);
    res.status(500).json({ error: 'Erreur lors de l\'envoi du mail' });
  }
});

app.listen(PORT, () => console.log(`Server listening on http://localhost:${PORT}`));
