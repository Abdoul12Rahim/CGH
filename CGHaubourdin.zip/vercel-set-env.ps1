# Script PowerShell pour ajouter automatiquement les variables d'environnement sur Vercel
# Usage: Ouvrir PowerShell dans le dossier du projet et lancer `.\vercel-set-env.ps1`

param(
    [string]$Token = $env:VERCEL_TOKEN
)

if (-not $Token) {
    $Token = Read-Host -Prompt "Entrez votre VERCEL_TOKEN (depuis https://vercel.com/account/tokens)"
}

if (-not $Token) {
    Write-Error "VERCEL_TOKEN requis. Annulation."
    exit 1
}

Write-Host "Lecture de .vercel/project.json pour recuperer le projet..." -ForegroundColor Cyan
$projectFile = Join-Path -Path (Get-Location) -ChildPath ".vercel/project.json"
$projectId = $null
if (Test-Path $projectFile) {
    try {
        $proj = Get-Content $projectFile -Raw | ConvertFrom-Json
        $projectId = $proj.projectId
        Write-Host "Project ID trouve : $projectId" -ForegroundColor Green
    } catch {
        Write-Warning "Impossible de lire .vercel/project.json"
    }
}

if (-not $projectId) {
    $projectId = Read-Host -Prompt "Entrez le Vercel Project ID"
}

if (-not $projectId) {
    Write-Error "Project ID requis. Annulation."
    exit 1
}

function Add-EnvVar {
    param([string]$name, [string]$value)
    if (-not $value) { 
        Write-Host "Valeur vide pour $name - saut" -ForegroundColor Yellow
        return 
    }
    Write-Host "Ajout de la variable $name..." -ForegroundColor Cyan
    npx vercel env add "$name" "$value" production --token $Token
    if ($LASTEXITCODE -eq 0) { 
        Write-Host "$name ajoute." -ForegroundColor Green 
    } else { 
        Write-Warning "Echec ajout $name (code $LASTEXITCODE)." 
    }
}

Write-Host "Saisir les valeurs (Appuie Entree pour garder vide)" -ForegroundColor Yellow
$smtpHost = Read-Host -Prompt "SMTP_HOST (ex smtp.mailtrap.io)"
$smtpPort = Read-Host -Prompt "SMTP_PORT (ex 587)"
$smtpUser = Read-Host -Prompt "SMTP_USER"
$smtpPass = Read-Host -Prompt "SMTP_PASS"
$smtpSecure = Read-Host -Prompt "SMTP_SECURE (true/false)"
$recipient = Read-Host -Prompt "RECIPIENT_EMAIL"

Add-EnvVar -name "SMTP_HOST" -value $smtpHost
Add-EnvVar -name "SMTP_PORT" -value $smtpPort
Add-EnvVar -name "SMTP_USER" -value $smtpUser
Add-EnvVar -name "SMTP_PASS" -value $smtpPass
Add-EnvVar -name "SMTP_SECURE" -value $smtpSecure
Add-EnvVar -name "RECIPIENT_EMAIL" -value $recipient

Write-Host "Termine. Verifie le tableau de bord Vercel pour confirmer les variables." -ForegroundColor Green
